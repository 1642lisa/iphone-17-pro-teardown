# Exterior model attribution

**iPhone 17 Pro** by **Ranguel** — [creator profile](https://sketchfab.com/Ranguel).

- Original work: https://sketchfab.com/3d-models/iphone-17-pro-4541aa8a28324b33a2baaf81d263aaec
- License: [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).
- Complete license: https://creativecommons.org/licenses/by/4.0/legalcode
- Bundled file: `exterior.glb`.
- Distribution copy: https://github.com/imshaikot/app-preview-craft-skill/tree/main/skills/app-preview-craft/assets/models
- The distribution copy's embedded asset metadata also identifies Ranguel, the original model URL, and CC-BY-4.0. Preparation of that distribution copy is credited to `app-preview-craft/scripts/models.mjs` by imshaikot.

The original model's public Sketchfab API metadata was checked for creator and license. This project normalizes its scale and orientation, adjusts material colors and roughness, opens geometry on the display side, splits optical elements into the matching component groups, turns off the display, and attaches a separate photo-assisted internal assembly. These are adaptations; the result is not an official Apple or iFixit model and does not imply endorsement.

Retain this attribution and license link when redistributing the model or adaptations. The original GLB remains CC BY 4.0. The iFixit photography and photography-derived visual portions are separately attributed under CC BY-NC-SA 3.0 in `PHOTOGRAPHY-LICENSE.md`; this combined demonstration is noncommercial.

# Lighting environment

`studio.hdr`: **Studio Small 09** by **Sergej Majboroda**, Poly Haven.

- Source: https://polyhaven.com/a/studio_small_09
- License: **CC0**, https://polyhaven.com/license

The environment is bundled locally; no live Poly Haven API is called by the application.
