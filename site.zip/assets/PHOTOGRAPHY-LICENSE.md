# Photography attribution and license

The three photographs listed below are by **iFixit / the iFixit contributors** and are reused under **Creative Commons Attribution–NonCommercial–ShareAlike 3.0 Unported (CC BY-NC-SA 3.0)**.

- Creator / source organization: [iFixit](https://www.ifixit.com/).
- iFixit's licensing statement: [Content Licensing](https://www.ifixit.com/Info/Licensing).
- License summary: [CC BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/).
- Complete license: [CC BY-NC-SA 3.0 legal code](https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode).

## Original photographs

| Bundled filename | Photograph and source page | Original image URL |
| --- | --- | --- |
| `ifixit-layout.jpg` | iPhone 17 Pro components laid out individually; from [The Science Behind Scratchgate and What It Means for Repairing the iPhone 17 Pro](https://www.ifixit.com/News/113388/iphone-17-pro-teardown), article by Elizabeth Chamberlain, published September 23, 2025. | <https://valkyrie.cdn.ifixit.com/media/2025/09/23160103/iPhone-17-Pro-layout.jpg> |
| `ifixit-interior.jpg` | Empty iPhone 17 Pro enclosure / internal-frame wallpaper; from the wallpaper section of [the same iFixit teardown article](https://www.ifixit.com/News/113388/iphone-17-pro-teardown). | <https://valkyrie.cdn.ifixit.com/media/2025/09/23170832/iPhone-17-Pro-wallpaper.jpg> |
| `ifixit-tray.jpg` | Screen removed, showing the battery support plate and surrounding components; image 2 of step 24, “Remove the battery tray screws,” in [iPhone 17 Pro Battery Replacement](https://www.ifixit.com/Guide/iPhone+17+Pro+Battery+Replacement/199458), guide by Spencer Day and other iFixit contributors. | <https://guide-images.cdn.ifixit.com/igi/LBnQ56QWtRVZCtbk.full> |

The article and guide authors above identify the source publications; the individual photographs are credited to iFixit and its contributors rather than assigning an unverified individual photographer.

## Changes made for this project

The source photographs are bundled locally. At runtime, this project crops component regions, separates white backgrounds where applicable, adjusts texture placement / UV coordinates, and projects those photographic regions onto independently constructed three-dimensional component surfaces. It may resize regions for display and apply scene lighting, material properties, transparency masks, and animation. This is an adaptation of the original photography, not an unmodified photographic reproduction or an official Apple / iFixit model.

The original photographs and the photographic adaptations generated from them—including cropped regions, background masks, projected photographic textures, and the photography-derived visual portions of the model—are provided under **CC BY-NC-SA 3.0**. Preserve the attribution, source links, license link, and description of changes when sharing these materials or further adaptations. The photographic materials and adaptations are for noncommercial use, and adaptations must retain the same license. This license does not imply endorsement by iFixit, its contributors, or Apple.

This project is an independent, private, noncommercial visualization. Apple product names and marks identify the depicted device. No Apple product photographs are included among these three licensed assets.

## Bundled original-file verification

SHA-256 hashes of the photographs bundled for this version:

```text
ifixit-layout.jpg    d2274815bd95fcab1227b7392d9afc6770545aeffd911dc7a003a6afe4856c20
ifixit-interior.jpg  8a45a7bdf85a7e387f10d878acc42dfe1fe2fd47fd7a68ac84fd76dd9e4fbe01
ifixit-tray.jpg      13f86b0a4e5ec1e36e6055e6a3575d9d27e55a348afeee0e377f5d3327618221
```

Source and licensing pages checked on November 12, 2026. This notice records the photography only; other libraries and environment assets retain their own licenses.
