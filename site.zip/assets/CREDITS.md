# Credits

## Exterior geometry

**iPhone 17 Pro**, by **Ranguel**, CC BY 4.0.

- Original: https://sketchfab.com/3d-models/iphone-17-pro-4541aa8a28324b33a2baaf81d263aaec
- Attribution and adaptation record: [MODEL-LICENSE.md](MODEL-LICENSE.md)

## Teardown photography

**iFixit and its contributors**, CC BY-NC-SA 3.0. The photographs are cropped, masked and projected onto reconstructed component surfaces.

- Full source, attribution and adaptation record: [PHOTOGRAPHY-LICENSE.md](PHOTOGRAPHY-LICENSE.md)

## Lighting

**Studio Small 09**, by **Sergej Majboroda / Poly Haven**, CC0.

- https://polyhaven.com/a/studio_small_09

## Software and fonts

- Three.js and its bundled add-ons: MIT, `../vendor/THREE-LICENSE.txt`.
- meshoptimizer decoder 0.22: Arseny Kapoulkine, MIT, `../vendor/MESHOPT-LICENSE.txt`.
- DM Sans and Manrope: SIL Open Font License, license files in `../vendor/`.

This independent, private demonstration has no affiliation with or endorsement by Apple, iFixit, Ranguel or Poly Haven. The combined photography-assisted demonstration is for noncommercial use.
