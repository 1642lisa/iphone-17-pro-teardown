import * as THREE from './vendor/three.module.js';

// Licensed teardown photography is projected onto the matching thin 3D surfaces.
// See assets/PHOTOGRAPHY-LICENSE.md for the original works and adaptation terms.
async function source(name) {
  const image = new Image();
  image.src = new URL(`./assets/${name}`, import.meta.url).href;
  await image.decode();
  return image;
}

function texture(image, crop, { cutout = false, maxHeight = 2048 } = {}) {
  const [x, y, width, height] = crop;
  const scale = Math.min(1, maxHeight / height);
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);
  const ctx = canvas.getContext('2d', { willReadFrequently: cutout });
  ctx.drawImage(image, x, y, width, height, 0, 0, canvas.width, canvas.height);
  if (cutout) {
    // Only remove neutral white connected to the border. White printed markings
    // and enclosed metal highlights remain part of the original photograph.
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = pixels.data, w = canvas.width, h = canvas.height;
    const visited = new Uint8Array(w * h), stack = [];
    function push(i) {
      if (i < 0 || i >= w * h || visited[i]) return;
      visited[i] = 1;
      const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2];
      if (Math.min(r, g, b) > 220 && Math.max(r, g, b) - Math.min(r, g, b) < 22) {
        data[i * 4 + 3] = 0;
        stack.push(i);
      }
    }
    for (let col = 0; col < w; col++) { push(col); push((h - 1) * w + col); }
    for (let row = 0; row < h; row++) { push(row * w); push(row * w + w - 1); }
    while (stack.length) {
      const i = stack.pop(), col = i % w;
      if (col) push(i - 1);
      if (col < w - 1) push(i + 1);
      push(i - w); push(i + w);
    }
    // Cut genuinely white openings and contract the photographic matte so the
    // original white studio background cannot leave a pale fringe on dark desks.
    for(let i=0;i<w*h;i++){const at=i*4;if(Math.min(data[at],data[at+1],data[at+2])>248&&Math.max(data[at],data[at+1],data[at+2])-Math.min(data[at],data[at+1],data[at+2])<5)data[at+3]=0;}
    for(let pass=0;pass<2;pass++){
      const alpha=new Uint8Array(w*h);for(let i=0;i<w*h;i++)alpha[i]=data[i*4+3];
      for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x;if(alpha[i]&&(!alpha[i-1]||!alpha[i+1]||!alpha[i-w]||!alpha[i+w]))data[i*4+3]=0;}
    }
    ctx.putImageData(pixels, 0, 0);
  }
  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = 12;
  return map;
}

export async function loadSurfaces() {
  const [layout, interior, cleanTray] = await Promise.all([
    source('ifixit-layout.jpg'), source('ifixit-interior.jpg'), source('ifixit-tray.jpg')
  ]);
  const crop = (rect, options) => texture(layout, rect, { cutout: true, ...options });
  return {
    interior: texture(interior, [0, 0, interior.width, interior.height]),
    tray: texture(cleanTray, [2030, 150, 2100, 4410]),
    display: crop([64, 153, 475, 1000]),
    vapor: crop([571, 174, 457, 790]),
    battery: crop([1038, 458, 414, 506]),
    logic: crop([1987, 149, 419, 261]),
    cameraAssembly: crop([1514, 150, 350, 329]),
    front: crop([1227, 189, 203, 87]),
    speaker: crop([1014, 974, 259, 165]),
    taptic: crop([1260, 992, 182, 131]),
    usb: crop([1493, 939, 440, 192]),
    lid: crop([1970, 465, 436, 669]),
  };
}

export function photographedMaterial(map, options = {}) {
  return new THREE.MeshPhysicalMaterial({
    map, color: '#555555', roughness: .66, metalness: .05,
    emissiveMap: map, emissive: '#ffffff', emissiveIntensity: .55,
    alphaTest: .25, alphaToCoverage:true, polygonOffset:true, polygonOffsetFactor:-1, polygonOffsetUnits:-3, transparent: false, ...options
  });
}
