import * as THREE from './vendor/three.module.js';
import { GLTFLoader } from './vendor/GLTFLoader.js';
import { MeshoptDecoder } from './vendor/meshopt_decoder.module.js';

// iPhone 17 Pro by Ranguel, CC BY 4.0. See assets/MODEL-LICENSE.md.
// The original shell is opened at its display side and connected to the
// photographic internal assembly; exterior camera covers remain on the shell.
function floatGeometry(source) {
  const geometry=source.clone();
  for(const[name,attribute]of Object.entries(geometry.attributes)){
    if(attribute.normalized||attribute.isInterleavedBufferAttribute){
      const values=new Float32Array(attribute.count*attribute.itemSize);
      const getters=['getX','getY','getZ','getW'];
      for(let i=0;i<attribute.count;i++)for(let k=0;k<attribute.itemSize;k++)values[i*attribute.itemSize+k]=attribute[getters[k]](i);
      geometry.setAttribute(name,new THREE.BufferAttribute(values,attribute.itemSize));
    }
  }
  return geometry;
}

function subset(geometry,predicate) {
  const p=geometry.attributes.position,old=geometry.index?.array||Array.from({length:p.count},(_,i)=>i),indices=[];
  for(let i=0;i<old.length;i+=3){
    const a=old[i],b=old[i+1],c=old[i+2];
    const x=(p.getX(a)+p.getX(b)+p.getX(c))/3,y=(p.getY(a)+p.getY(b)+p.getY(c))/3,z=(p.getZ(a)+p.getZ(b)+p.getZ(c))/3;
    if(predicate(x,y,z))indices.push(a,b,c);
  }
  if(!indices.length)return null;
  const result=geometry.clone();result.clearGroups();result.setIndex(indices);result.computeBoundingBox();result.computeBoundingSphere();return result;
}

export async function attachExterior(model) {
  const gltf=await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync('./assets/exterior.glb');
  const alignment=new THREE.Group();alignment.add(gltf.scene);alignment.rotation.y=Math.PI;alignment.updateMatrixWorld(true);
  const initial=new THREE.Box3().setFromObject(alignment),size=initial.getSize(new THREE.Vector3());
  alignment.scale.setScalar(15/size.y);alignment.updateMatrixWorld(true);
  const bounds=new THREE.Box3().setFromObject(alignment),center=bounds.getCenter(new THREE.Vector3());alignment.position.x-=center.x;alignment.position.y-=center.y;
  const displayGlass=gltf.scene.getObjectByName('Object_21');
  alignment.updateMatrixWorld(true);const front=new THREE.Box3().setFromObject(displayGlass).max.z;
  alignment.position.z+=.4375-front;alignment.updateMatrixWorld(true);

  const frame=model.components.get('frame'),display=model.components.get('display'),back=model.components.get('back');
  for(const child of [...frame.children])if(!child.userData.keepInterior)frame.remove(child);
  for(const child of [...display.children])if(child.material?.map!==model.photos.display&&child.geometry?.type!=='TubeGeometry'&&child.geometry?.type!=='BufferGeometry')display.remove(child);
  for(const child of [...back.children])back.remove(child);
  // Put the actual photographed display back just outside the imported rear plate.
  display.traverse(o=>{if(o.isMesh&&o.material.map===model.photos.display){o.position.z=-.237;o.material.polygonOffset=true;o.material.polygonOffsetFactor=-1;o.material.polygonOffsetUnits=-3;}});
  // Remove the previous approximate optical faces, retaining sensor housings,
  // mounting feet and flexible connectors around the imported internal optics.
  for(const id of['maincam','ultracam','telecam']){
    const group=model.components.get(id);
    for(const child of group.children.slice(2,5))group.remove(child);
  }
  // The imported display has a deeper metal rear plate; preserve layer spacing.
  for(const id of['tray','battery','vapor','logic','frontcam']){
    const group=model.components.get(id);group.userData.base.z-=.11;group.position.copy(group.userData.base);
  }
  const materials=new Map();
  function materialFor(original){
    if(materials.has(original))return materials.get(original);
    const m=original.clone(),name=original.name;
    if(name==='Anodized_aluminum'){
      m.color.set('#c75e2c');m.metalness=1;m.roughness=.30;m.specularIntensity=.9;m.normalScale?.set(.035,.035);m.userData.finishIndex=0;
    }else if(name==='Frosted_glass'||name==='Glass_tint'){
      m.color.set('#a44519');m.metalness=0;m.roughness=.42;m.transmission=0;m.opacity=1;m.transparent=false;m.normalScale?.set(.018,.018);m.userData.finishIndex=1;
    }else if(name==='Glass'){
      m.color.set('#080a0d');m.metalness=0;m.roughness=.045;m.opacity=1;m.transparent=false;m.transmission=.10;m.ior=1.52;
    }else if(name==='OLED'){
      m.map=null;m.emissiveMap=null;m.color.set('#020305');m.emissive?.set(0);m.emissiveIntensity=0;m.roughness=.09;m.metalness=0;
    }else if(name==='OLED_off'){
      m.color.set('#030406');m.roughness=.20;m.metalness=0;
    }else if(name==='Camera_Lens')m.envMapIntensity=.75;
    m.userData.baseEmissive=m.emissive?.clone();m.userData.baseEmissiveIntensity=m.emissiveIntensity;
    materials.set(original,m);return m;
  }
  const meshList=[];gltf.scene.traverse(o=>{if(o.isMesh)meshList.push(o);});
  const cameraCenters=[['maincam',2.23,6.08],['ultracam',2.23,4.09],['telecam',.32,5.06]];
  let attached=0;
  function add(geometry,material,id){
    const group=model.components.get(id);geometry.translate(-group.userData.base.x,-group.userData.base.y,-group.userData.base.z);
    const mesh=new THREE.Mesh(geometry,material);mesh.castShadow=true;mesh.receiveShadow=true;mesh.userData.partId=id;mesh.userData.importedExterior=true;group.add(mesh);attached++;
  }
  for(const source of meshList){
    const material=materialFor(source.material),geometry=floatGeometry(source.geometry);geometry.applyMatrix4(source.matrixWorld);
    const n=Number(source.name.split('_').at(-1)),name=source.material.name;
    if(name==='Camera_Lens'||name==='Camera_mirror_filter'){
      const route=(x,y,z)=>z>.05&&y>6.15&&Math.abs(x)<1.1?'frontcam':cameraCenters.reduce((best,[id,cx,cy])=>((x-cx)**2+(y-cy)**2<best.distance?{id,distance:(x-cx)**2+(y-cy)**2}:best),{id:'maincam',distance:Infinity}).id;
      for(const id of['maincam','ultracam','telecam','frontcam']){const section=subset(geometry,(x,y,z)=>route(x,y,z)===id);if(section)add(section,material,id);}
    }else{
      const id=n>=19?'display':(name==='Frosted_glass'||name==='Glass_tint')?'back':'frame';
      const cleaned=id==='frame'?subset(geometry,(x,y,z)=>!(z>-.245&&Math.abs(x)<3.18&&Math.abs(y)<7.10)):geometry;
      if(cleaned)add(cleaned,material,id);
    }
  }
  model.meshCount=0;model.root.traverse(o=>{if(o.isMesh)model.meshCount++;});
  model.exteriorAsset={author:'Ranguel',license:'CC BY 4.0',meshes:attached};
  return model;
}
