import * as THREE from './vendor/three.module.js';
import { RoundedBoxGeometry } from './vendor/RoundedBoxGeometry.js';
import { loadSurfaces, photographedMaterial } from './photo-surfaces.js';
export { parts } from './parts-data.js';

// A scene unit is 10 mm. The front and rear envelope is +/-0.4375,
// excluding the raised camera plateau and lens covers.
const cache = new Map();
const physical = (color, metalness, roughness, extra={}) => new THREE.MeshPhysicalMaterial({color,metalness,roughness,...extra});

function grain() {
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=512;
  const ctx=canvas.getContext('2d'), pixels=ctx.createImageData(512,512);
  let seed=8519;
  for(let i=0;i<pixels.data.length;i+=4){seed=(seed*1664525+1013904223)>>>0;const v=185+(seed>>>26);pixels.data[i]=v;pixels.data[i+1]=v;pixels.data[i+2]=v;pixels.data[i+3]=255;}
  ctx.putImageData(pixels,0,0);const t=new THREE.CanvasTexture(canvas);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(.7,1.5);return t;
}

function shape(w,h,r,cx=0,cy=0,path=false){
  const s=path?new THREE.Path():new THREE.Shape();const x=cx-w/2,y=cy-h/2;
  s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);
  s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);
  s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;
}
function outline(points){const s=new THREE.Shape();points.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();return s;}
function holes(s,items){for(const item of items){if(item.r){const p=new THREE.Path();p.absarc(item.x,item.y,item.r,0,Math.PI*2,true);s.holes.push(p);}else s.holes.push(shape(item.w,item.h,item.radius||.1,item.x,item.y,true));}return s;}
function mesh(parent,geometry,material,x=0,y=0,z=0){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
function solid(parent,s,d,mat,z=0,{bevel=.008,bevelDepth=bevel,segments=4}={}){
  const g=new THREE.ExtrudeGeometry(s,{depth:d,bevelEnabled:bevel>0,bevelSize:bevel,bevelThickness:bevelDepth,bevelSegments:segments,curveSegments:48});
  return mesh(parent,g,mat,0,0,z-d/2);
}
function plate(parent,w,h,d,r,x,y,z,material,cutouts=[],options={}){const m=solid(parent,holes(shape(w,h,r),cutouts),d,material,z,options);m.position.x=x;m.position.y=y;return m;}
function box(parent,w,h,d,x,y,z,material,r=.025){const key=`box:${w}:${h}:${d}:${r}`;if(!cache.has(key))cache.set(key,new RoundedBoxGeometry(w,h,d,4,Math.min(r,w/2,h/2,d/2)));return mesh(parent,cache.get(key),material,x,y,z);}
function disk(parent,r,d,x,y,z,material,segments=96){const key=`disk:${r}:${d}:${segments}`;if(!cache.has(key))cache.set(key,new THREE.CylinderGeometry(r,r,d,segments));const m=mesh(parent,cache.get(key),material,x,y,z);m.rotation.x=Math.PI/2;return m;}
function annulus(parent,outer,inner,depth,x,y,z,material){const s=new THREE.Shape();s.absarc(0,0,outer,0,Math.PI*2,false);const p=new THREE.Path();p.absarc(0,0,inner,0,Math.PI*2,true);s.holes.push(p);const m=solid(parent,s,depth,material,z,{bevel:.004,segments:3});m.position.x=x;m.position.y=y;return m;}
function surface(parent,s,map,bounds,z,options={}){
  const geo=new THREE.ShapeGeometry(s,48),p=geo.attributes.position,uv=geo.attributes.uv;
  const [minX,minY,w,h]=bounds;
  for(let i=0;i<p.count;i++)uv.setXY(i,(p.getX(i)-minX)/w,(p.getY(i)-minY)/h);
  const m=mesh(parent,geo,photographedMaterial(map,options),0,0,z);return m;
}
function photoCard(parent,map,w,h,d,material,z=0){
  const canvas=map.image,context=canvas.getContext('2d'),pixels=context.getImageData(0,0,canvas.width,canvas.height).data;
  const width=canvas.width,height=canvas.height,edges=new Map(),all=[];
  const opaque=(x,y)=>x>=0&&x<width&&y>=0&&y<height&&pixels[(y*width+x)*4+3]>128;
  const edge=(x1,y1,x2,y2)=>{const item={start:[x1,y1],end:[x2,y2],used:false},key=`${x1},${y1}`;if(!edges.has(key))edges.set(key,[]);edges.get(key).push(item);all.push(item);};
  for(let y=0;y<height;y++)for(let x=0;x<width;x++)if(opaque(x,y)){
    if(!opaque(x-1,y))edge(x,y,x,y+1);
    if(!opaque(x,y+1))edge(x,y+1,x+1,y+1);
    if(!opaque(x+1,y))edge(x+1,y+1,x+1,y);
    if(!opaque(x,y-1))edge(x+1,y,x,y);
  }
  let boundary=[],largest=0;
  for(const first of all){if(first.used)continue;const loop=[];let next=first;
    while(next&&!next.used){next.used=true;loop.push(next.start);const key=next.end.join(',');next=edges.get(key)?.find(e=>!e.used);}
    let area=0;for(let i=0;i<loop.length;i++){const a=loop[i],b=loop[(i+1)%loop.length];area+=a[0]*b[1]-b[0]*a[1];}
    if(Math.abs(area)>largest){largest=Math.abs(area);boundary=loop;}
  }
  // Keep re-entrant cutouts: a row envelope would incorrectly fill the open
  // space between connectors and the board with a rectangular green surface.
  const corners=boundary.filter((b,i)=>{const a=boundary[(i+boundary.length-1)%boundary.length],c=boundary[(i+1)%boundary.length];return(b[0]-a[0])*(c[1]-b[1])!==(b[1]-a[1])*(c[0]-b[0]);});
  const points=corners.map(([x,y])=>[x/width*w-w/2,h/2-y/height*h]);
  const s=points.length>5?outline(points):shape(w,h,Math.min(w,h)*.07);solid(parent,s,d,material,z,{bevel:.001});
  surface(parent,s,map,[-w/2,-h/2,w,h],z+d/2+.012);return s;
}
function curve(parent,points,width,material){return mesh(parent,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),Math.min(2400,points.length*12),width,6,false),material);}
function ribbon(parent,points,width,material,traces){
  const center=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));
  const positions=[],uvs=[],indices=[];const segments=42;
  for(let i=0;i<=segments;i++){const t=i/segments,p=center.getPoint(t),tangent=center.getTangent(t);const left=new THREE.Vector3(-tangent.y,tangent.x,0).normalize().multiplyScalar(width/2);for(const side of[-1,1]){const v=p.clone().addScaledVector(left,side);positions.push(...v.toArray());uvs.push(side<0?0:1,t);}if(i<segments){const a=i*2;indices.push(a,a+2,a+1,a+1,a+2,a+3);}}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geo.setIndex(indices);geo.computeVertexNormals();const mat=material.clone();mat.side=THREE.DoubleSide;mesh(parent,geo,mat);
  if(traces)for(let i=-3;i<=3;i++){curve(parent,points.map(([x,y,z])=>[x+i*width/10,y,z+.006]),.003,traces);}
}
function socket(parent,x,y,z,w,h,mats){box(parent,w,h,.055,x,y,z,mats.black,.012);box(parent,w-.045,h-.025,.018,x,y,z+.033,mats.steel,.005);for(let i=0;i<Math.floor(w/.05);i++)box(parent,.017,h*.50,.008,x-w/2+.04+i*.05,y,z+.045,mats.gold,.002);}

function roundedContour(w,h,r,count=32){const points=[];const corners=[[w/2-r,h/2-r,0],[-w/2+r,h/2-r,Math.PI/2],[-w/2+r,-h/2+r,Math.PI],[w/2-r,-h/2+r,Math.PI*1.5]];for(const[cx,cy,start]of corners)for(let i=0;i<count;i++){const a=start+i/count*Math.PI/2;points.push(new THREE.Vector2(cx+Math.cos(a)*r,cy+Math.sin(a)*r));}return points;}
function bodySide(parent,material){
  const profile=[[-.4375,.145],[-.429,.095],[-.413,.045],[-.380,.012],[-.330,0],[-.18,0],[.18,0],[.300,0],[.340,.012],[.375,.044],[.400,.10]];
  const positions=[],uvs=[],indices=[];const count=128;
  for(let k=0;k<profile.length;k++){const[z,inset]=profile[k];const points=roundedContour(7.19-inset*2,15-inset*2,1.19-inset);for(let j=0;j<count;j++){positions.push(points[j].x,points[j].y,z);uvs.push(j/count,k/(profile.length-1));}}
  for(let k=0;k<profile.length-1;k++)for(let j=0;j<count;j++){const a=k*count+j,b=k*count+(j+1)%count,c=a+count,d=b+count;const x=(positions[a*3]+positions[b*3])/2,y=(positions[a*3+1]+positions[b*3+1])/2;const z=(profile[k][0]+profile[k+1][0])/2;if(y<-7.48&&Math.abs(x)<.60&&z>-.18&&z<.18)continue;indices.push(a,b,d,a,d,c);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geo.setIndex(indices);geo.computeVertexNormals();return mesh(parent,geo,material);
}

function screw(parent,x,y,z,mats,bottom=false){
  const g=new THREE.Group();g.position.set(x,y,z);g.userData.origin=g.position.clone();g.userData.bottom=bottom;parent.add(g);
  disk(g,.043,.17,0,0,-.075,mats.steel,24);disk(g,.083,.025,0,0,.017,mats.steel,48);
  const s=new THREE.Shape();for(let i=0;i<24;i++){const a=i/24*Math.PI*2,r=i%4===0?.044:.029;const x=Math.cos(a)*r,y=Math.sin(a)*r;i?s.lineTo(x,y):s.moveTo(x,y);}s.closePath();mesh(g,new THREE.ShapeGeometry(s),mats.black,0,0,.032);return g;
}
function convexLens(parent,r,z,material,sag=.04){
  const positions=[0,0,z-sag],uvs=[.5,.5],indices=[];const radial=14,around=96;
  for(let i=1;i<=radial;i++)for(let j=0;j<around;j++){const a=j/around*Math.PI*2,radius=r*i/radial;positions.push(Math.cos(a)*radius,Math.sin(a)*radius,z-sag*(1-(radius/r)**2));uvs.push(.5+Math.cos(a)*i/radial*.5,.5+Math.sin(a)*i/radial*.5);}
  for(let j=0;j<around;j++)indices.push(0,1+(j+1)%around,1+j);
  for(let i=0;i<radial-1;i++)for(let j=0;j<around;j++){const a=1+i*around+j,b=1+i*around+(j+1)%around,c=a+around,d=b+around;indices.push(a,d,b,a,c,d);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geo.setIndex(indices);geo.computeVertexNormals();return mesh(parent,geo,material);
}

export async function buildPhone(scene){
  const photos=await loadSurfaces();const fine=grain();
  const mats={
    body:physical('#c75e2c',1,.29,{roughnessMap:fine,bumpMap:fine,bumpScale:.00065}),
    glass:physical('#a44519',0,.44,{clearcoat:.32,clearcoatRoughness:.32,ior:1.52,roughnessMap:fine}),
    edge:physical('#dc8a52',1,.18),steel:physical('#a6abae',1,.27),
    black:physical('#08090a',0,.50),graphite:physical('#1d2021',.08,.68),
    gold:physical('#b79b55',1,.32),flex:physical('#39231a',0,.50),
    pcb:physical('#202b25',0,.67),copper:physical('#ae673e',1,.40),
    optical:physical('#010204',0,.09,{ior:1.52,clearcoat:.18,clearcoatRoughness:.10,envMapIntensity:.22}),
    sapphire:physical('#0a0e16',0,.028,{transmission:.26,thickness:.035,ior:1.52,attenuationColor:'#425579',attenuationDistance:1.2,clearcoat:.45,iridescence:.10,iridescenceThicknessRange:[180,320],envMapIntensity:.35}),
    shield:physical('#454a4e',1,.52,{bumpMap:fine,bumpScale:.0007}),
    led:physical('#d9ddcf',0,.23,{clearcoat:1,ior:1.46}),
  };
  const root=new THREE.Group();scene.add(root);const components=new Map();const fasteners=[];
  const component=(id,position)=>{const g=new THREE.Group();g.name=id;g.position.set(...position);g.userData={partId:id,base:g.position.clone()};root.add(g);components.set(id,g);return g;};

  const frame=component('frame',[0,0,0]);bodySide(frame,mats.body);
  const centers=[[2.23,6.08],[2.23,4.09],[.32,5.06]];
  const drilled=centers.map(([x,y])=>({x,y,r:.803}));
  const rear=holes(shape(6.98,14.77,1.06),[{x:0,y:-2.03,w:6.27,h:9.80,radius:.86},...drilled,{x:-2.27,y:6.05,r:.34},{x:-2.27,y:3.91,r:.31}]);
  solid(frame,rear,.045,mats.body,-.398,{bevel:.008,segments:4});
  const plateauHoles=drilled.map(p=>({...p,y:p.y-5.08})).concat([{x:-2.27,y:.97,r:.34},{x:-2.27,y:-1.17,r:.31}]);
  plate(frame,6.42,3.85,.065,.64,0,5.08,-.477,mats.body,plateauHoles,{bevel:.085,bevelDepth:.07,segments:8});
  plate(frame,7.04,14.86,.04,1.10,0,0,.357,mats.black,[{x:0,y:0,w:6.72,h:14.54,radius:.96}],{bevel:.007});
  plate(frame,6.94,14.74,.04,1.05,0,0,.319,mats.steel,[{x:0,y:0,w:6.65,h:14.44,radius:.94}],{bevel:.006});
  const inside=shape(6.81,14.68,.96);const internalSurface=surface(frame,inside,photos.interior,[-3.405,-7.34,6.81,14.68],-.240,{roughness:.78,metalness:.07,emissiveIntensity:.21});internalSurface.userData.keepInterior=true;
  for(const side of[-1,1])for(const y of[-5.65,5.58])box(frame,.019,.065,.60,side*3.596,y,-.015,mats.graphite,.003);
  for(const[side,y,h]of[[-1,4.48,.60],[-1,2.88,1.11],[-1,1.34,1.11],[1,3.16,1.39],[1,-2.85,1.46]]){
    box(frame,.055,h+.13,.295,side*3.60,y,-.015,mats.black,.018);
    box(frame,.065,h,.255,side*3.625,y,-.015,mats.body,.024);
    if(side===1&&y<0)box(frame,.009,h-.15,.155,side*3.665,y,-.005,mats.optical,.004);
  }
  for(let i=0;i<5;i++)for(const sign of[-1,1]){const vent=disk(frame,.048,.017,sign*(1.57+i*.255),-7.502,-.025,mats.black,24);vent.rotation.x=0;}
  for(let i=0;i<12;i++){const x=i%2===0?-3.27:3.27,y=-5.70+Math.floor(i/2)*2.04;box(frame,.105,.24,.16,x,y,-.025,mats.steel,.012);}

  const back=component('back',[0,-2.03,-.4025]);
  plate(back,6.25,9.78,.052,.85,0,0,0,mats.glass,[],{bevel:.009,bevelDepth:.009,segments:6});
  // The trademark silhouette is a small reflective mark, not an embossed toy logo.
  const logoCanvas=document.createElement('canvas');logoCanvas.width=384;logoCanvas.height=480;
  const lc=logoCanvas.getContext('2d');lc.fillStyle='#fff';lc.beginPath();lc.moveTo(194,143);lc.bezierCurveTo(156,107,91,141,99,207);lc.bezierCurveTo(103,264,126,310,155,307);lc.bezierCurveTo(184,294,191,295,219,307);lc.bezierCurveTo(240,316,265,282,276,255);lc.bezierCurveTo(231,236,226,193,266,169);lc.bezierCurveTo(244,136,218,129,194,143);lc.fill();lc.beginPath();lc.ellipse(209,105,13,29,.64,0,Math.PI*2);lc.fill();const logoMap=new THREE.CanvasTexture(logoCanvas);logoMap.colorSpace=THREE.SRGBColorSpace;
  const logoMat=physical('#ad5228',.76,.19,{map:logoMap,transparent:true,alphaTest:.25,depthWrite:false});logoMat.userData.finishRole='logo';const mark=mesh(back,new THREE.PlaneGeometry(1.95,2.44),logoMat,0,-.05,-.039);mark.rotation.y=Math.PI;
  // Exterior glass keeps a dielectric material so its finish responds to the
  // studio instead of re-lighting an already lit, orange photographic panel.

  const display=component('display',[0,0,.365]);
  plate(display,7.045,14.85,.090,1.095,0,0,.013,mats.black,[],{bevel:.008,bevelDepth:.008,segments:6});
  const front=shape(6.96,14.76,1.055);mesh(display,new THREE.ShapeGeometry(front,64),physical('#030405',0,.075,{clearcoat:1,clearcoatRoughness:.045,ior:1.52,envMapIntensity:1.2}),0,0,.0725);
  const island=plate(display,1.84,.49,.006,.245,0,6.44,.077,mats.black,[],{bevel:0});
  disk(display,.071,.003,.55,6.44,.082,mats.optical,48);
  const backSurface=surface(display,shape(6.98,14.77,1.05),photos.display,[-3.49,-7.385,6.98,14.77],-.041,{roughness:.64,metalness:.26});backSurface.rotation.y=Math.PI;
  ribbon(display,[[-2.44,.10,-.055],[-2.64,1.3,-.07],[-2.36,2.2,-.06]],.42,mats.flex,mats.gold);

  const tray=component('tray',[0,0,.210]);
  const trayOutline=[[-2.96,-6.09],[2.94,-6.09],[3.10,-5.84],[3.10,4.9],[2.65,5.42],[1.4,5.42],[1.4,5.95],[-1.35,5.95],[-1.35,4.85],[-2.20,4.85],[-2.20,1.80],[-2.96,1.80]];
  const trayShape=outline(trayOutline);solid(tray,trayShape,.035,mats.graphite,0,{bevel:.006});surface(tray,trayShape,photos.tray,[-3.595,-7.50,7.19,15],.026,{roughness:.77,metalness:.12,emissiveIntensity:.24});

  const battery=component('battery',[.30,-2.06,.020]);
  photoCard(battery,photos.battery,5.85,7.16,.31,mats.steel);ribbon(battery,[[-1.8,3.50,.05],[-1.8,4.05,.06],[-2.45,4.20,.06]],.32,mats.flex,mats.gold);socket(battery,-2.45,4.2,.075,.48,.17,mats);
  const vapor=component('vapor',[0,.70,-.060]);
  const vaporShape=outline([[-3.02,-6.4],[1.0,-6.4],[1.25,-6.14],[1.25,-5.36],[2.94,-5.36],[2.94,4.9],[2.5,5.38],[1.4,5.38],[1.4,5.8],[-2.8,5.8],[-2.8,4.9],[-3.02,4.9]]);
  solid(vapor,vaporShape,.035,mats.steel,0,{bevel:.004});surface(vapor,vaporShape,photos.vapor,[-3.16,-6.4,6.32,12.2],.025,{roughness:.66,metalness:.40});
  const logic=component('logic',[-.25,4.82,.047]);
  photoCard(logic,photos.logic,5.90,3.64,.065,mats.pcb);

  function rearCamera(id,index){
    const[x,y]=centers[index],g=component(id,[x,y,-.19]);
    box(g,1.64,1.69,.28,0,0,.11,mats.graphite,.09);plate(g,1.56,1.60,.018,.14,0,0,.268,mats.shield,[],{bevel:.006});
    const cover=new THREE.Group();cover.position.set(x,y,-.19);cover.scale.setScalar(.90);frame.add(cover);
    disk(cover,.894,.14,0,0,-.325,mats.body);
    annulus(cover,.900,.874,.018,0,0,-.405,mats.edge);
    annulus(cover,.874,.723,.035,0,0,-.425,mats.black);
    const bowlPoints=[[.62,-.395],[.67,-.431],[.73,-.448]].map(p=>new THREE.Vector2(...p));const bowlMat=mats.optical.clone();bowlMat.roughness=.075;bowlMat.envMapIntensity=.15;bowlMat.side=THREE.DoubleSide;const bowl=mesh(g,new THREE.LatheGeometry(bowlPoints,128),bowlMat);bowl.rotation.x=Math.PI/2;
    disk(g,.620,.018,0,0,-.382,new THREE.MeshStandardMaterial({color:'#000102',roughness:1,metalness:0,envMapIntensity:0}));
    const inner=physical('#08091b',0,.03,{ior:1.62,transmission:.16,thickness:.12,attenuationColor:'#6758ab',attenuationDistance:.30,clearcoat:.20,envMapIntensity:.35,iridescence:.10,iridescenceThicknessRange:[180,300]});
    convexLens(g,index===0?.38:index===1?.25:.34,-.30,inner,.13);
    // A continuous optical cover reflects the HDR softboxes; no fabricated iris teeth.
    convexLens(cover,.716,-.474,mats.sapphire);
    cover.traverse(o=>{if(o.isMesh)o.userData.partId=id;});
    for(const sx of[-1,1]){box(g,.20,.30,.04,sx*.84,.66,.09,mats.steel,.025);}
    ribbon(g,[[0,-.82,.12],[.1,-1.14,.10],[.62,-1.27,.08]],.30,mats.flex,mats.gold);socket(g,.62,-1.27,.105,.4,.15,mats);return g;
  }
  rearCamera('maincam',0);rearCamera('ultracam',1);rearCamera('telecam',2);

  const frontcam=component('frontcam',[0,6.68,.10]);photoCard(frontcam,photos.front,2.50,1.07,.14,mats.steel);
  const lidar=component('lidar',[-2.27,5.02,-.49]);
  disk(lidar,.325,.07,0,1.03,-.045,mats.led);annulus(lidar,.326,.280,.008,0,1.03,-.09,mats.edge);
  for(const r of[.25,.17,.09])annulus(lidar,r,r-.010,.003,0,1.03,-.088,mats.led);
  disk(lidar,.298,.04,0,-1.11,-.020,mats.black);convexLens(lidar,.275,-.048,mats.sapphire);
  ribbon(lidar,[[0,.9,.04],[.48,.5,.04],[.48,-1.3,.04]],.15,mats.flex,mats.gold);

  const taptic=component('taptic',[1.86,-6.37,.02]);photoCard(taptic,photos.taptic,2.49,1.55,.30,mats.steel);
  const speaker=component('speaker',[-1.74,-6.21,.01]);photoCard(speaker,photos.speaker,3.05,1.94,.30,mats.black);
  const usb=component('usbc',[0,-6.05,-.045]);photoCard(usb,photos.usb,6.18,2.70,.07,mats.flex);
  const portShape=holes(shape(1.02,.28,.13),[{x:0,y:0,w:.87,h:.17,radius:.08}]);const portShell=solid(usb,portShape,.38,mats.steel,0,{bevel:.012});portShell.rotation.x=Math.PI/2;portShell.position.set(0,-1.05,0);box(usb,.72,.028,.22,0,-1.24,0,mats.black,.007);for(let i=0;i<12;i++)box(usb,.027,.009,.1,-.33+i*.06,-1.34,.025,mats.gold,.001);
  const magsafe=component('magsafe',[0,-1.8,-.27]);
  disk(magsafe,2.08,.025,0,0,0,mats.graphite);
  const coilPoints=[];for(let i=0;i<1600;i++){const t=i/1599,r=.61+t*1.18,a=t*Math.PI*2*18;coilPoints.push([Math.cos(a)*r,Math.sin(a)*r,-.022]);}curve(magsafe,coilPoints,.013,mats.copper);
  for(let i=0;i<32;i++){const a=i/32*Math.PI*2;const p=box(magsafe,.22,.27,.035,Math.sin(a)*2.0,Math.cos(a)*2.0,-.045,mats.steel,.009);p.rotation.z=-a;}
  box(magsafe,.25,.80,.025,0,-2.55,-.03,mats.steel,.01);
  const flex=component('flex',[-2.77,-.35,.035]);ribbon(flex,[[0,-5.35,0],[.02,-2.3,.02],[.22,1.2,.02],[.05,3.9,.03],[1.0,4.5,.035]],.26,mats.flex,mats.gold);for(const y of[-3.7,-.9,2.3]){ribbon(flex,[[.1,y,.02],[.7,y,.04],[.95,y+.3,.05]],.22,mats.flex,mats.gold);socket(flex,.95,y+.3,.065,.45,.15,mats);}

  const screws=component('screws',[0,0,.254]);
  for(let i=0;i<14;i++){const x=i%2===0?-3.05:3.05,y=-5.9+Math.floor(i/2)*1.91;fasteners.push(screw(screws,x,y,0,mats));}
  fasteners.push(screw(screws,-.94,-7.37,-.21,mats,true));fasteners.push(screw(screws,.94,-7.37,-.21,mats,true));

  for(const group of components.values()){
    const clones=new Map();group.traverse(o=>{if(o.isMesh){o.userData.partId=o.userData.partId||group.name;const clone=m=>{if(!clones.has(m)){const c=m.clone();c.userData.baseEmissive=c.emissive?.clone();c.userData.baseEmissiveIntensity=c.emissiveIntensity;clones.set(m,c);}return clones.get(m);};o.material=Array.isArray(o.material)?o.material.map(clone):clone(o.material);}});
  }
  let meshCount=0;root.traverse(o=>{if(o.isMesh)meshCount++;});
  return {root,components,meshCount,materials:mats,fasteners,photos};
}

export function setFinish(model,key){
  const palette={orange:['#c75e2c','#a44519','#dc8a52','#ad5228'],silver:['#bdc1c4','#a5aaad','#dce0e1','#777c80'],blue:['#253347','#1e2c40','#4c6078','#192b40']}[key];if(!palette)return;
  const targets=[model.materials.body,model.materials.glass,model.materials.edge];const previous=targets.map(m=>m.color.clone());
  model.root.traverse(o=>{if(o.isMesh)for(const m of(Array.isArray(o.material)?o.material:[o.material])){if(m.userData.finishRole==='logo'){m.color.set(palette[3]);continue;}if(m.userData.finishIndex===undefined){const i=previous.findIndex(c=>m.color?.equals(c));if(i>=0)m.userData.finishIndex=i;}if(m.userData.finishIndex!==undefined)m.color.set(palette[m.userData.finishIndex]);}});targets.forEach((m,i)=>m.color.set(palette[i]));
}

const smooth=t=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*(3-2*t);};
export function posePhone(model,progress){
  const p=THREE.MathUtils.clamp(progress,0,1)*7;
  for(const g of model.components.values()){g.position.copy(g.userData.base);g.rotation.set(0,0,0);}
  const get=id=>model.components.get(id);
  // Turn the intact phone over above the mat, then open its left-hand edge.
  const turn=Math.PI*(1-smooth(p/.55));model.root.rotation.y=turn;
  model.root.position.z=Math.sin(turn)*3.65-.45*(1-smooth(p/.55));
  const open=smooth((p-.45)/.55),disconnect=smooth(p-1);const angle=-1.87*open-(Math.PI-1.87)*disconnect;
  const display=get('display');display.rotation.y=angle;
  display.position.x=-3.40+3.40*Math.cos(angle)-1.05*disconnect;
  display.position.z=.365-3.40*Math.sin(angle)+.14*open;
  const lifted=smooth(p-3),separated=smooth(p-4),core=smooth(p-5),spread=smooth(p-6);
  const travel=smooth((p-3)/.8),arch=Math.sin(Math.PI*travel)*2.1;
  for(const id of['tray','battery','vapor']){const g=get(id);g.position.x+=7.55*lifted;g.position.z+=arch-.525*lifted;}
  get('tray').position.y+=1.5*separated;get('battery').position.y-=5.8*separated;get('vapor').position.x+=7.5*separated;get('vapor').position.y+=1.8*separated;
  get('logic').position.x-=8.2*core;get('logic').position.y+=5.8*core;get('logic').position.z+=.4*core;
  for(const[id,x,y]of[['maincam',-1.5,10.1],['ultracam',1.2,10.1],['telecam',3.9,10.1]]){const g=get(id);g.position.x=THREE.MathUtils.lerp(g.position.x,x,core);g.position.y=THREE.MathUtils.lerp(g.position.y,y,core);g.position.z+=.3*core;}
  for(const id of['maincam','ultracam','telecam'])get(id).rotation.y=Math.PI*core;
  const otherTargets={frontcam:[-8.7,-9.8],lidar:[6.7,10.3],taptic:[4.6,-9.2],speaker:[.2,-9.2],usbc:[-4.7,-9.7],magsafe:[15.4,12.2],flex:[-4.8,-1.7],back:[22.5,-4.5]};
  for(const[id,[x,y]]of Object.entries(otherTargets)){const g=get(id);g.position.x=THREE.MathUtils.lerp(g.position.x,x,spread);g.position.y=THREE.MathUtils.lerp(g.position.y,y,spread);g.position.z=THREE.MathUtils.lerp(g.position.z,.32,spread);}
  get('back').rotation.y=Math.PI*spread;get('magsafe').rotation.y=Math.PI*spread;
  for(let i=0;i<model.fasteners.length;i++){const fastener=model.fasteners[i],removed=smooth(p-(fastener.userData.bottom?0:2));const target=new THREE.Vector3(-6.8+(i%4)*.36,-6.2+Math.floor(i/4)*.36,.12);fastener.position.lerpVectors(fastener.userData.origin,target,removed);fastener.rotation.z=removed*Math.PI*2;}
  // A removed part settles onto the same work surface rather than floating.
  model.root.updateMatrixWorld(true);
  const rest=(id,factor)=>{if(factor<=0)return;const group=get(id),bounds=new THREE.Box3().setFromObject(group);group.position.z+=(-.89-bounds.min.z)*factor;group.updateMatrixWorld(true);};
  rest('display',disconnect);
  for(const id of['tray','battery','vapor'])rest(id,separated);
  for(const id of['logic','maincam','ultracam','telecam'])rest(id,core);
  for(const id of Object.keys(otherTargets))rest(id,spread);
  model.root.updateMatrixWorld(true);
}
