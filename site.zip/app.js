import * as THREE from './vendor/three.module.js';
import { OrbitControls } from './vendor/OrbitControls.js';
import { HDRLoader } from './vendor/HDRLoader.js';
import { RectAreaLightUniformsLib } from './vendor/RectAreaLightUniformsLib.js';
import { buildPhone, parts, setFinish, posePhone } from './realistic-model.js';
import { attachExterior } from './exterior.js';

const $=id=>document.getElementById(id),stage=$('stage');
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
const state={explosion:0,targetExplosion:0,selected:null,isolate:false,labels:false,finish:'orange',view:'iso',rotation:false};
const steps=[
  ['整机检查','转动手机，观察铝合金、玻璃、镜头镀膜和机身接缝。'],
  ['打开屏幕','屏幕绕左侧边缘抬起，背板、连接排线与固定托盘显露。'],
  ['分开屏幕','屏幕移到一侧，连接位置和内部支撑结构得以完整观察。'],
  ['收纳固定螺丝','紧固件移至一侧，观察固定托盘周围的安装孔。'],
  ['移出电池托盘','电池与支撑托盘一同离开机身，露出内部电路和机壳。'],
  ['分离电池与散热层','分开展示金属封装电池、支撑板与散热层。'],
  ['移出影像与主板','三枚相机与主板离开机壳，可单独查看光学面与连接器。'],
  ['部件总览','各组件按区域铺开，选择任意部件进行近距离观察。'],
];
let renderer;
try{renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});}
catch(error){$('loading').innerHTML='<p>请使用支持 WebGL 的浏览器，并开启硬件加速。</p>';throw error;}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(stage.clientWidth,stage.clientHeight);
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.93;
$('canvas-wrap').appendChild(renderer.domElement);
renderer.domElement.setAttribute('aria-label','iPhone 17 Pro 三维模型：拖动旋转、滚轮缩放、点击组件、双击聚焦');
renderer.domElement.setAttribute('role','img');
const scene=new THREE.Scene();scene.background=new THREE.Color('#1a1e23');
const camera=new THREE.PerspectiveCamera(34,stage.clientWidth/stage.clientHeight,.1,250);
const controls=new OrbitControls(camera,renderer.domElement);
controls.enableDamping=true;controls.dampingFactor=.075;controls.minDistance=3.5;controls.maxDistance=160;
controls.autoRotateSpeed=.5;controls.maxPolarAngle=Math.PI*.96;
const pmrem=new THREE.PMREMGenerator(renderer);
const hdr=await new HDRLoader().loadAsync('./assets/studio.hdr');
hdr.mapping=THREE.EquirectangularReflectionMapping;
scene.environment=pmrem.fromEquirectangular(hdr).texture;
scene.environmentIntensity=.82;scene.environmentRotation.set(0,.55,0);
hdr.dispose();pmrem.dispose();
scene.add(new THREE.HemisphereLight('#d7e6f5','#16191d',.28));
const key=new THREE.DirectionalLight('#fff8ef',1.45);key.position.set(-9,16,20);
key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-26;key.shadow.camera.right=26;
key.shadow.camera.top=26;key.shadow.camera.bottom=-26;key.shadow.camera.near=.1;key.shadow.camera.far=80;
key.shadow.normalBias=.012;key.shadow.bias=-.00005;key.shadow.radius=4;scene.add(key);
const fill=new THREE.DirectionalLight('#e0e9f5',.85);fill.position.set(9,6,-18);scene.add(fill);
const strip=new THREE.DirectionalLight('#ffffff',.45);strip.position.set(-18,-2,-8);scene.add(strip);
RectAreaLightUniformsLib.init();
const rearSoftbox=new THREE.RectAreaLight('#fff4e8',1.8,3.0,18);rearSoftbox.position.set(6,-3,-12);rearSoftbox.lookAt(0,0,0);scene.add(rearSoftbox);
const edgeSoftbox=new THREE.RectAreaLight('#e3eeff',2.0,2.0,13);edgeSoftbox.position.set(-9,4,-7);edgeSoftbox.lookAt(0,0,0);scene.add(edgeSoftbox);
const frontSoftbox=new THREE.RectAreaLight('#fff9f1',2.0,5,18);frontSoftbox.position.set(6,-3,12);frontSoftbox.lookAt(0,0,0);scene.add(frontSoftbox);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:'#20252a',roughness:.95,metalness:0}));
ground.position.z=-.90;ground.receiveShadow=true;scene.add(ground);
const model=await attachExterior(await buildPhone(scene));
let cameraTween=null,toastTimer,dragStart=null,dragged=false,ready=false;

function presetVector(view){
  const p=state.targetExplosion,shortStage=Math.max(1,(stage.clientHeight/Math.max(260,stage.clientHeight-120))/(800/680));
  const scale=(stage.clientWidth/stage.clientHeight<.8?1.15:1)*shortStage;
  if(view==='iso')return new THREE.Vector3(...(p<.02?[-11,7,27]:p<.49?[12,10,29]:p<.95?[12,17,47]:[3,7,62])).multiplyScalar(scale);
  const flipped=p<.02?-1:1;
  return new THREE.Vector3(...({front:[0,1,(p<.49?32:57)*flipped],back:[-7,5,(p<.49?-31:-57)*flipped],side:[p<.49?32:57,6,7]}[view]||[12,10,29])).multiplyScalar(scale);
}
function transitionCamera(target,position,duration=1000){
  cameraTween={fromPosition:camera.position.clone(),fromTarget:controls.target.clone(),toPosition:position.clone(),toTarget:target.clone(),start:performance.now(),duration:reducedMotion?0:duration};
}
function updateVisibility(){for(const[id,g]of model.components)g.visible=!state.isolate||id===state.selected;}
function updateIsolateButton(){$('isolate-btn').textContent=state.isolate?'显示全部组件':'单独显示';$('isolate-btn').setAttribute('aria-pressed',String(state.isolate));}
function overview(view=state.view,immediate=false){
  state.view=view;state.isolate=false;updateVisibility();updateIsolateButton();
  const target=new THREE.Vector3(0,0,0);
  if(state.targetExplosion>.02&&state.targetExplosion<.49)target.x=-1.6;
  else if(state.targetExplosion>=.49)target.set(2.2,state.targetExplosion>.95?-1:0,0);
  let position=presetVector(view).add(target);
  if(state.targetExplosion>.95&&view==='iso'){
    posePhone(model,1);const bounds=new THREE.Box3().setFromObject(model.root),size=bounds.getSize(new THREE.Vector3());bounds.getCenter(target);
    const distance=Math.max(size.y,size.x/camera.aspect)/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2)))*1.17;
    position=target.clone().add(new THREE.Vector3(.035,.10,1).normalize().multiplyScalar(distance));posePhone(model,state.explosion);
  }
  if(immediate){camera.position.copy(position);controls.target.copy(target);cameraTween=null;}
  else transitionCamera(target,position);
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
}

$('part-count').textContent=parts.length;
$('part-list').innerHTML=parts.map((p,i)=>`<button class="part-row" data-part="${p.id}" aria-pressed="false"><span class="part-num">${String(i+1).padStart(2,'0')}</span><span>${p.name}</span><span class="part-dot"></span></button>`).join('');
const overviewMarkup=`<p class="component-en">IPHONE 17 PRO / TEARDOWN</p><h2>从外壳，到内腔。</h2><p class="detail-description">按下「下一步」，逐层打开手机。<br>拖动查看材质与组件侧面；选择一个部件，可单独放大。</p><ul class="spec-list"><li><span>机身</span><strong>阳极氧化铝合金</strong></li><li><span>尺寸</span><strong>150.0 × 71.9 mm</strong></li><li><span>厚度</span><strong>8.75 mm</strong></li><li><span>内部表面</span><strong>实拍辅助材质</strong></li></ul>`;
function showDetails(){
  const part=parts.find(p=>p.id===state.selected);
  if(!part){$('detail-content').innerHTML=overviewMarkup;$('detail-number').textContent=`00 / ${parts.length}`;$('detail-actions').hidden=true;return;}
  $('detail-number').textContent=`${String(parts.indexOf(part)+1).padStart(2,'0')} / ${parts.length}`;
  $('detail-content').innerHTML=`<p class="component-en">${part.en}</p><h2>${part.name}</h2><p class="detail-description">${part.desc}</p><ul class="spec-list">${part.specs.map(([key,value])=>`<li><span>${key}</span><strong>${value}</strong></li>`).join('')}</ul>`;
  $('detail-actions').hidden=false;
}
function highlight(){
  for(const[id,g]of model.components)g.traverse(o=>{if(o.isMesh)for(const m of(Array.isArray(o.material)?o.material:[o.material]))if(m.emissive){m.emissive.copy(m.userData.baseEmissive||new THREE.Color(0));m.emissiveIntensity=m.userData.baseEmissiveIntensity||0;if(id===state.selected&&!m.map&&m.roughness>.2){m.emissive.set('#72553b');m.emissiveIntensity=.018;}}});
  document.querySelectorAll('[data-part]').forEach(b=>{const selected=b.dataset.part===state.selected;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
}
function selectPart(id){
  if(!model.components.has(id))return;
  state.selected=id;showDetails();highlight();updateVisibility();updateIsolateButton();
  const row=document.querySelector(`[data-part="${id}"]`);
  if(row){const list=$('part-list');list.scrollTop=Math.max(0,row.offsetTop-list.offsetTop-list.clientHeight/2);}
}
function clearSelection(reset=true){state.selected=null;state.isolate=false;showDetails();highlight();updateVisibility();updateIsolateButton();if(reset)overview();}
function focusSelected(){
  if(!state.selected)return;
  const group=model.components.get(state.selected);group.updateMatrixWorld(true);
  const bounds=new THREE.Box3().setFromObject(group),target=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3());
  const extent=Math.max(size.y,size.x/camera.aspect,size.z*.7);
  const distance=Math.max(4.7,extent/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2)))*1.28);
  const rear=['maincam','ultracam','telecam','lidar','magsafe','back','display'].includes(state.selected);
  const direction=(rear?new THREE.Vector3(-.20,.15,-1):new THREE.Vector3(.16,.12,1)).applyQuaternion(group.getWorldQuaternion(new THREE.Quaternion()));
  transitionCamera(target,target.clone().add(direction.normalize().multiplyScalar(distance)));
}
function toast(message){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').classList.add('visible');toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),2300);}
function explodeTo(value){
  state.targetExplosion=THREE.MathUtils.clamp(value,0,1);
  $('explode-range').value=String(Math.round(value*100));$('explode-value').textContent=`${Math.round(value*100)}%`;
  const i=Math.min(7,Math.round(value*7));
  $('view-caption').textContent=steps[i][0];$('step-title').textContent=steps[i][0];$('step-description').textContent=steps[i][1];
  $('step-number').textContent=`${String(i+1).padStart(2,'0')} / 08`;$('step-prev').disabled=i===0;$('step-next').disabled=i===7;
  if(state.isolate){state.isolate=false;updateVisibility();updateIsolateButton();}
}
function goStep(i){clearSelection(false);explodeTo(i/7);overview('iso');}
$('part-list').addEventListener('click',e=>{const b=e.target.closest('[data-part]');if(b)selectPart(b.dataset.part);});
$('focus-btn').addEventListener('click',()=>{state.isolate=true;updateVisibility();updateIsolateButton();focusSelected();});
$('isolate-btn').addEventListener('click',()=>{state.isolate=!state.isolate;updateVisibility();updateIsolateButton();focusSelected();});
$('deselect-btn').addEventListener('click',()=>clearSelection());
$('reset-view').addEventListener('click',()=>{clearSelection(false);overview('iso');toast('已恢复当前拆解步骤的视角');});
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>overview(b.dataset.view)));
$('rotate-btn').addEventListener('click',()=>{state.rotation=!state.rotation;controls.autoRotate=state.rotation;$('rotate-btn').classList.toggle('active',state.rotation);$('rotate-btn').setAttribute('aria-pressed',String(state.rotation));});
$('labels-btn').addEventListener('click',()=>{state.labels=!state.labels;$('labels-btn').classList.toggle('active',state.labels);$('labels-btn').setAttribute('aria-pressed',String(state.labels));});
$('labels-btn').classList.remove('active');$('labels-btn').setAttribute('aria-pressed','false');
$('explode-range').addEventListener('input',e=>{explodeTo(Number(e.target.value)/100);if(state.selected)clearSelection(false);});
$('explode-range').addEventListener('change',()=>overview('iso'));
$('explode-btn').addEventListener('click',()=>goStep(Math.min(7,Math.round(state.targetExplosion*7)+1)));
$('step-prev').addEventListener('click',()=>goStep(Math.max(0,Math.round(state.targetExplosion*7)-1)));
$('step-next').addEventListener('click',()=>goStep(Math.min(7,Math.round(state.targetExplosion*7)+1)));
$('assemble-btn').addEventListener('click',()=>goStep(0));
const finishNames={orange:'星宇橙色',silver:'银色',blue:'深蓝色'};
function chooseFinish(value){state.finish=value;setFinish(model,value);$('finish-name').textContent=finishNames[value];document.querySelectorAll('[data-finish]').forEach(b=>{const selected=b.dataset.finish===value;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});}
document.querySelectorAll('[data-finish]').forEach(b=>b.addEventListener('click',()=>chooseFinish(b.dataset.finish)));
$('capture-btn').addEventListener('click',()=>{renderer.render(scene,camera);const a=document.createElement('a');a.download=`iPhone-17-Pro-step-${Math.round(state.explosion*7)+1}.png`;a.href=renderer.domElement.toDataURL('image/png');a.click();toast('截图已保存');});
$('about-btn').addEventListener('click',()=>$('about-dialog').showModal());
$('about-close').addEventListener('click',()=>$('about-dialog').close());
$('about-dialog').addEventListener('click',e=>{if(e.target===$('about-dialog')){const r=$('about-dialog').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('about-dialog').close();}});

const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
function picked(event){
  const rect=renderer.domElement.getBoundingClientRect();pointer.set((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1);
  raycaster.setFromCamera(pointer,camera);const meshes=[];
  for(const group of model.components.values())if(group.visible)group.traverse(o=>{if(o.isMesh)meshes.push(o);});
  for(const hit of raycaster.intersectObjects(meshes,false)){
    const map=hit.object.material?.map,canvas=map?.image;
    if(hit.uv&&canvas instanceof HTMLCanvasElement){const x=Math.max(0,Math.min(canvas.width-1,Math.floor(hit.uv.x*canvas.width))),y=Math.max(0,Math.min(canvas.height-1,Math.floor((1-hit.uv.y)*canvas.height)));if(canvas.getContext('2d').getImageData(x,y,1,1).data[3]<70)continue;}
    return hit.object.userData.partId;
  }
}
renderer.domElement.addEventListener('pointerdown',e=>{dragStart=[e.clientX,e.clientY];dragged=false;cameraTween=null;});
renderer.domElement.addEventListener('pointermove',e=>{if(dragStart&&Math.hypot(e.clientX-dragStart[0],e.clientY-dragStart[1])>5)dragged=true;});
renderer.domElement.addEventListener('pointerup',e=>{if(!dragged){const id=picked(e);if(id)selectPart(id);}dragStart=null;});
renderer.domElement.addEventListener('pointercancel',()=>dragStart=null);
renderer.domElement.addEventListener('dblclick',e=>{const id=picked(e);if(id){selectPart(id);focusSelected();}});
controls.addEventListener('start',()=>cameraTween=null);
const labelIds=['display','tray','battery','logic','maincam','frame'],labelNodes=new Map(),lineNodes=new Map();
for(const id of labelIds){const button=document.createElement('button');button.className='part-label';button.textContent=parts.find(p=>p.id===id).name;button.addEventListener('click',()=>selectPart(id));$('labels').appendChild(button);labelNodes.set(id,button);const line=document.createElementNS('http://www.w3.org/2000/svg','line');$('label-lines').appendChild(line);lineNodes.set(id,line);}
function updateLabels(){
  const w=stage.clientWidth,h=stage.clientHeight,occupied=[];let shown=0;
  for(const[id,node]of labelNodes){
    const line=lineNodes.get(id),group=model.components.get(id);
    const visible=state.labels&&group.visible&&shown<(w<450?3:6)&&(state.explosion>.05||id===state.selected||id==='frame');
    node.hidden=!visible;line.style.display=visible?'':'none';if(!visible)continue;
    const p=new THREE.Box3().setFromObject(group).getCenter(new THREE.Vector3()).project(camera);
    const x=(p.x*.5+.5)*w,y=(-p.y*.5+.5)*h;
    if(p.z>1||p.z<-1||x<5||x>w-5||y<56||y>h-100){node.hidden=true;line.style.display='none';continue;}
    const nw=node.offsetWidth||80,nh=node.offsetHeight||25,right=x>w/2;
    const lx=THREE.MathUtils.clamp(x+(right?35:-nw-35),12,w-nw-12);let ly=THREE.MathUtils.clamp(y-16,62,h-112);
    for(let i=0;i<5&&occupied.some(r=>lx<r.x+r.w+5&&lx+nw+5>r.x&&ly<r.y+r.h+5&&ly+nh+5>r.y);i++)ly=THREE.MathUtils.clamp(ly+30,62,h-112);
    if(occupied.some(r=>lx<r.x+r.w+4&&lx+nw+4>r.x&&ly<r.y+r.h+4&&ly+nh+4>r.y)){node.hidden=true;line.style.display='none';continue;}
    occupied.push({x:lx,y:ly,w:nw,h:nh});node.style.transform=`translate(${lx}px,${ly}px)`;node.classList.toggle('active',state.selected===id);
    line.setAttribute('x1',x);line.setAttribute('y1',y);line.setAttribute('x2',lx+(right?0:nw));line.setAttribute('y2',ly+nh/2);shown++;
  }
}
let previous=performance.now(),frames=0;
function animate(now){
  requestAnimationFrame(animate);const delta=Math.min((now-previous)/1000,.05);previous=now;
  if(Math.abs(state.targetExplosion-state.explosion)>.00001){state.explosion=reducedMotion?state.targetExplosion:THREE.MathUtils.lerp(state.explosion,state.targetExplosion,1-Math.exp(-delta*4.5));posePhone(model,state.explosion);}
  if(cameraTween){const t=cameraTween.duration===0?1:THREE.MathUtils.clamp((now-cameraTween.start)/cameraTween.duration,0,1),s=t*t*(3-2*t);camera.position.lerpVectors(cameraTween.fromPosition,cameraTween.toPosition,s);controls.target.lerpVectors(cameraTween.fromTarget,cameraTween.toTarget,s);if(t>=1)cameraTween=null;}
  controls.update();ground.visible=camera.position.z>0&&!state.isolate;renderer.render(scene,camera);
  if(frames++%4===0)updateLabels();
  if(!ready){ready=true;$('loading').style.opacity=0;setTimeout(()=>$('loading')?.remove(),450);document.body.dataset.ready='true';}
}
posePhone(model,0);showDetails();chooseFinish('orange');explodeTo(0);overview('iso',true);requestAnimationFrame(animate);
new ResizeObserver(()=>{const w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h);}).observe(stage);
renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();toast('图形上下文已中断，请刷新恢复。');});
window.phoneExplorer={
  getState:()=>({...state,version:2,step:Math.round(state.targetExplosion*7),meshCount:model.meshCount,partCount:parts.length,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,camera:camera.position.toArray(),target:controls.target.toArray(),photographicSurfaces:Object.keys(model.photos).length,exteriorAsset:model.exteriorAsset}),
  getPartScreenPosition:id=>{const group=model.components.get(id);if(!group)return null;const p=new THREE.Box3().setFromObject(group).getCenter(new THREE.Vector3()).project(camera);return{x:(p.x*.5+.5)*stage.clientWidth,y:(-p.y*.5+.5)*stage.clientHeight};},
};
